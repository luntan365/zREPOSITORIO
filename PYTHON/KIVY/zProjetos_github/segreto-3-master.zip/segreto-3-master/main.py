#!/usr/bin/env python3
from segreto.app import SegretoApp
import os

if __name__ == '__main__':
    app = SegretoApp()
    app.run()
