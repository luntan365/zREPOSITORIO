FlappyKivy
==========

![Screenshot](/screenshots/shot.png)

Flappy Bird clone programmed in Python + Kivy!

[<img src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif">](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=TGRE7G6ASVFVS)

## Controls

Tap the touch screen, click using mouse, or start FlappyKivy with keyboard support:

```sh
$ python FlappyBird.py -c input:keyboard:True
```
